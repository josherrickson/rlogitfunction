library(testthat)
library(rlogitfunction)

test_check("rlogitfunction")
